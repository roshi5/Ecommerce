


<!DOCTYPE html>
<html lang="en">
<head>
   <style>
      .pdt-card {
           width: 300px;
           display: inline-block;
           margin: 10px;
           border: 2px solid grey;
           padding: 10px;
      }
      .pdt-img {
            width: 100%;
            height: 250px;
      }
      .price {
        font-size: 24px;
      }
      .price::before {
        content: "Rs.";
      }
      .name {
            font-size: 22px;
            font-weight: bold;
            color: orange;
      }
      .category {
            font-size: 22px;
            font-weight: bold;
            color: brown;
      }
      .details {
            font-size: 22px;
            font-weight: bold;
            color: brown;
      }
      .btn {
           background: green;
      }
   </style>
</head>
<body>

<?php
include "../shared/authguard_customer.php";
include "menu.html";
include "../shared/connection.php";


$sql_query = "SELECT * FROM cart JOIN product ON cart.pid = product.pid WHERE userid = $_SESSION[userid]";
$sql_obj = mysqli_query($conn, $sql_query);

if (!$sql_obj) {
    die("SQL Error: " . mysqli_error($conn));
}

$total = 0; // Initialize the total variable

while ($row = mysqli_fetch_assoc($sql_obj)) {
    echo "<div class='pdt-card'>
         <div class='name'>$row[name]</div>
         <div class='price'>$row[price]</div>
         <div class='code'>$row[code]</div>
         <img class='pdt-img' src='$row[imgpath]'>
         <div class='category'>$row[category]</div>
         <div class='details'>$row[details]</div>
         <div class='text-center'>
            <a href='deletecart.php?cartid=$row[cartid]'>
                <button class='btn btn-danger'>Remove Cart</button>
            </a>
         </div>
    </div>";
    $total += $row['price']; // Add the price of each item to the total
}

echo "<div class='big-primary p-3 d-flex justify-content-around'>
     <h1 class='text-white'>Total Payable = Rs. $total</h1>    
     <form action='createorder.php' method='post' class='d-flex'>
       <textarea required name='address' placeholder='Delivery Address' col='50'></textarea>
       <button type='submit' class='btn btn-success'>Place Order</button>
     </form>
</div>";
?>

</body>
</html>
