<?php
include "../shared/authguard_customer.php";

if (isset($_SESSION['userid'])) {
    $userid = $_SESSION['userid'];
} else {
    echo "User not logged in";
    exit();
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['address'])) {
    $deliveryAddress = $_POST['address'];
    
    include "../shared/connection.php";
    $cartItemsQuery = "SELECT * FROM cart JOIN product ON cart.pid=product.pid WHERE cart.userid=$userid";
    $cartItemsResult = mysqli_query($conn, $cartItemsQuery);

    if (!$cartItemsResult) {
        echo "Failed to fetch cart items";
        exit();
    }

    // Initialize total payment
    $totalPayment = 0;

    while ($cartItem = mysqli_fetch_assoc($cartItemsResult)) {
        $productId = $cartItem['pid'];
        $productName = $cartItem['name'];
        $productPrice = $cartItem['price'];

        $insertOrderQuery = "INSERT INTO orders (userid, pid, delivery_address, product_name, product_price) VALUES ($userid, $productId, '$deliveryAddress', '$productName', $productPrice)";

        $insertOrderResult = mysqli_query($conn, $insertOrderQuery);

        if (!$insertOrderResult) {
            echo "Failed to insert order for product: $productName";
        } else {
            // Update total payment
            $totalPayment += $productPrice;
        }
    }

    // Clear the cart
    $clearCartQuery = "DELETE FROM cart WHERE userid=$userid";
    $clearCartResult = mysqli_query($conn, $clearCartQuery);

    if (!$clearCartResult) {
        echo "Failed to clear the cart";
    }
    $orderedItemsQuery = "SELECT * FROM orders WHERE userid=$userid";
    $orderedItemsResult = mysqli_query($conn, $orderedItemsQuery);

    if ($orderedItemsResult) {
        echo "<div style='text-align: center;'>"; 
        echo "<h3>Ordered Items:</h3>";
        while ($orderedItem = mysqli_fetch_assoc($orderedItemsResult)) {
            echo '<div style="display: inline-block; width: 50%; padding: 10px; box-sizing: border-box; border: 1px solid #ddd; margin: 5px;">';
            echo "Product Name: " . $orderedItem['product_name'] . "<br>";
            echo "Product Price: " . $orderedItem['product_price'] . "<br>";
            echo "Delivery Address: " . $orderedItem['delivery_address'] . "<br>";
            echo '</div>';
        }
        echo "</div>"; 
        echo "<div style='text-align: center;'>";
        echo "<h3>Total Payment: Rs." . $totalPayment . "</h3>";
        echo "</div>";
    } else {
        echo "Failed to fetch ordered items";
    }
} else {
    echo "Delivery address not provided";
}
?>
