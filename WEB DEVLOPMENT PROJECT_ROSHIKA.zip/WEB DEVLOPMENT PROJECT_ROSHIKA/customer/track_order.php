<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Track Your Order</title>
</head>
<body>
    <h1>Track Your Order</h1>
    <form method="post" action="track_order.php">
        <label for="order_id">Order ID:</label>
        <input type="text" id="order_id" name="orderid">
        <input type="submit" value="Track">
    </form>
    <?php
    // Handle form submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $orderid = $_POST['orderid'];

        // Perform a database query to retrieve order information
        include 'db_connection.php'; // Include your database connection file

        $sql = "SELECT * FROM orders WHERE orderid = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $order_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $order = $result->fetch_assoc();
            ?>
            <h2>Order Details</h2>
            <p>Order ID: <?php echo $order['orderid']; ?></p>
            <p>Product Name: <?php echo $order['product_name']; ?></p>
            <p>Order Status: <?php echo $order['order_status']; ?></p>
            <p>Order Date: <?php echo $order['order_date']; ?></p>
            <?php
        } else {
            echo "<p>Order not found. Please check your order ID.</p>";
        }

        // Close the database connection
        $stmt->close();
        $conn->close();
    }
    ?>
</body>
</html>
