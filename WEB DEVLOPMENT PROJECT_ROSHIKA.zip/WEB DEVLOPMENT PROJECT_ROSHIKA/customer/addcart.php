<?php
include "../shared/authguard_customer.php";
$pid = $_GET['pid'];
$userid = $_SESSION['userid'];
echo "Received pid = $pid";
include "../shared/connection.php";
$checkQuery = "SELECT * FROM cart WHERE userid = $userid AND pid = $pid";
$checkResult = mysqli_query($conn, $checkQuery);

if (mysqli_num_rows($checkResult) > 0) {
    
    echo "Product is already in the cart. Quantity updated if needed.";
} else {
    
    $insertQuery = "INSERT INTO cart (userid, pid) VALUES ($userid, $pid)";
    $status = mysqli_query($conn, $insertQuery);

    if ($status) {
        echo "Added to cart successfully";
        header("location:viewcart.php");
    }
    else {
        echo "Failed to add to cart";
        echo mysqli_error($conn);
    }
}
?>
